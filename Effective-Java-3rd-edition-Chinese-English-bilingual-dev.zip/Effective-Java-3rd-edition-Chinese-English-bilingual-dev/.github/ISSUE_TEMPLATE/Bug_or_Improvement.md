---
name: Bug or Improvement
about: Bugfix or translation quality improvement（bug 修复或翻译质量改进）
---

<!-- Please don't delete this template -->
<!-- ISSUE TEMPLATE -->

**The location of the content：（内容所在位置）：**
<!-- (e.g. `Item xxx`, where "xxx" is the Item number) -->
Item xxx

**Description and expected results（描述及预期结果）：**
